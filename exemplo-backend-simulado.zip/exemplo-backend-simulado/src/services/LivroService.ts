import { Livro } from '../models/Livro';

export class LivroService {
  // Array privado que simula o banco de dados dos livros
  private livros: Livro[] = [];
  // Controle para gerar IDs únicos para cada livro criado
  private nextId = 1;

  // Método para criar um novo livro
  criarLivro(titulo: string, autor: string, preco: number, quantidade: number): Livro {
    // Validação simples para garantir dados válidos
    if (!titulo || !autor || preco < 0 || quantidade < 0) {
      console.log('Dados inválidos');
    }
    // Cria um novo objeto Livro com ID único e os dados fornecidos
    const livro = new Livro(this.nextId++, titulo, autor, preco, quantidade);
    // Adiciona o livro à lista interna
    this.livros.push(livro);
    // Retorna o livro criado
    return livro;
  }

  // Método para listar todos os livros cadastrados
  listarLivros(): Livro[] {
    return this.livros;
  }

  // Método para buscar um livro pelo ID
  buscarPorId(id: number): Livro | undefined {
    // Retorna o livro correspondente ou undefined se não encontrar
    return this.livros.find(l => l.id === id);
  }

  // Método para atualizar os dados de um livro pelo ID
  atualizarLivro(id: number, titulo: string, autor: string, preco: number, quantidade: number): boolean {
    // Procura o livro na lista
    const livro = this.buscarPorId(id);
    // Se não encontrado, retorna false
    if (!livro) return false;
    // Atualiza os campos do livro com os novos valores
    livro.titulo = titulo;
    livro.autor = autor;
    livro.preco = preco;
    livro.quantidade = quantidade;
    return true;
  }

  // Método para deletar um livro pelo ID
  deletarLivro(id: number): boolean {
    // Encontra o índice do livro no array
    const index = this.livros.findIndex(l => l.id === id);
    // Se não achar, retorna false
    if (index === -1) return false;
    // Remove o livro da lista
    this.livros.splice(index, 1);
    return true;
  }
}
