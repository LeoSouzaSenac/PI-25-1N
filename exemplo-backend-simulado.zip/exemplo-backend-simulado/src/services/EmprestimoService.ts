import { Emprestimo } from '../models/Emprestimo';
import { LivroService } from './LivroService';
import { UsuarioService } from './UsuarioService';

export class EmprestimoService {
  // Array privado que guarda todos os empréstimos registrados
  private emprestimos: Emprestimo[] = [];
  // Controle para gerar IDs únicos para cada empréstimo
  private nextId = 1;

  // Recebe as instâncias dos serviços de Usuário e Livro para poder consultá-los e atualizar
  constructor(
    private usuarioService: UsuarioService,
    private livroService: LivroService
  ) {}

  // Método para registrar um empréstimo de livro para um usuário
  emprestarLivro(usuarioId: number, livroId: number): Emprestimo | undefined {
    // Busca o usuário pelo ID informado
    const usuario = this.usuarioService.buscarPorId(usuarioId);
    if (!usuario) {
      console.log('Usuário não encontrado');
      return undefined; // interrompe a execução se não achar o usuário
    }
  
    // Busca o livro pelo ID informado
    const livro = this.livroService.buscarPorId(livroId);
    if (!livro) {
      console.log('Livro não encontrado');
      return undefined; // interrompe se o livro não existir
    }
  
    // Verifica se há exemplares disponíveis para empréstimo
    if (livro.quantidade <= 0) {
      console.log('Livro indisponível para empréstimo');
      return undefined; // não continua se não houver livro disponível
    }
  
    // Diminui a quantidade do livro no estoque simulando o empréstimo
    livro.alterarQuantidade(-1);
  
    // Define as datas do empréstimo: data atual e data de devolução 7 dias depois
    const dataEmprestimo = new Date();
    const dataDevolucao = new Date();
    dataDevolucao.setDate(dataEmprestimo.getDate() + 7);
  
    // Cria um novo objeto Emprestimo com um ID único
    const emprestimo = new Emprestimo(this.nextId++, usuarioId, livroId, dataEmprestimo, dataDevolucao);
    // Armazena o empréstimo na lista interna
    this.emprestimos.push(emprestimo);
    // Retorna o empréstimo criado
    return emprestimo;
  }
  
  // Método para devolver um livro emprestado, removendo o empréstimo
  devolverLivro(idEmprestimo: number): boolean {
    // Busca o índice do empréstimo pelo ID
    const index = this.emprestimos.findIndex(e => e.id === idEmprestimo);
    if (index === -1) {
      console.log('Empréstimo não encontrado');
      return false; // não achou o empréstimo para devolver
    }

    // Obtém o empréstimo e o livro relacionado
    const emprestimo = this.emprestimos[index];
    const livro = this.livroService.buscarPorId(emprestimo.livroId);
    if (!livro) {
      console.log('Livro não encontrado');
      return false; // erro inesperado se o livro não existir mais
    }

    // Incrementa a quantidade do livro ao devolver
    livro.alterarQuantidade(1);

    // Remove o empréstimo da lista, pois foi concluído
    this.emprestimos.splice(index, 1);
    return true;
  }

  // Método para renovar um empréstimo, adicionando 7 dias na devolução, só pode renovar 1 vez
  renovarEmprestimo(idEmprestimo: number): boolean {
    // Busca o empréstimo pelo ID
    const emprestimo = this.emprestimos.find(e => e.id === idEmprestimo);
    if (!emprestimo) {
      console.log('Empréstimo não encontrado');
      return false; // não achou o empréstimo
    }
  
    // Verifica se já foi renovado antes
    if (emprestimo.renovado) {
      console.log('Este empréstimo já foi renovado uma vez.');
      return false; // não permite renovar mais de uma vez
    }
  
    // Marca como renovado e aumenta a data de devolução em 7 dias
    emprestimo.renovar();
    return true;
  }
  
  // Lista todos os empréstimos feitos por um usuário específico
  listarEmprestimosPorUsuario(usuarioId: number): Emprestimo[] {
    return this.emprestimos.filter(e => e.usuarioId === usuarioId);
  }

  // Retorna todos os empréstimos registrados
  listarTodos(): Emprestimo[] {
    return this.emprestimos;
  }
}
