import { Usuario } from '../models/Usuario';

export class UsuarioService {
  // Array privado para armazenar os usuários cadastrados (simula o banco de dados)
  private usuarios: Usuario[] = [];
  // Controle de ID incremental para os novos usuários
  private nextId = 1;

  // Método para criar um novo usuário
  criarUsuario(nome: string, email: string, senha: string): Usuario {
    // Validação simples para checar se os dados foram preenchidos
    if (!nome || !email || !senha) {
      console.log('Dados inválidos');
    }

    // Verifica se já existe usuário com o mesmo email
    if (this.usuarios.find(u => u.email === email)) {
      console.log('Email já cadastrado');
    }

    // Cria um novo usuário com ID único, nome, email e senha
    const usuario = new Usuario(this.nextId++, nome, email, senha);
    // Adiciona o usuário ao array de usuários
    this.usuarios.push(usuario);
    // Retorna o usuário criado
    return usuario;
  }

  // Método para listar todos os usuários cadastrados
  listarUsuarios(): Usuario[] {
    return this.usuarios;
  }

  // Método para buscar um usuário pelo ID
  buscarPorId(id: number): Usuario | undefined {
    // Retorna o usuário encontrado ou undefined se não achar
    return this.usuarios.find(u => u.id === id);
  }

  // Método para atualizar nome e email de um usuário pelo ID
  atualizarUsuario(id: number, nome: string, email: string): boolean {
    const usuario = this.buscarPorId(id);
    // Se não encontrar o usuário, retorna false indicando falha
    if (!usuario) return false;
    // Atualiza os dados do usuário
    usuario.nome = nome;
    usuario.email = email;
    return true;
  }

  // Método para deletar um usuário pelo ID
  deletarUsuario(id: number): boolean {
    // Busca o índice do usuário no array
    const index = this.usuarios.findIndex(u => u.id === id);
    // Se não encontrar, retorna false
    if (index === -1) return false;
    // Remove o usuário do array
    this.usuarios.splice(index, 1);
    return true;
  }
}
