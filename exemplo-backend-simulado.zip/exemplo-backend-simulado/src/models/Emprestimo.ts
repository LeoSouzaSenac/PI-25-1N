export class Emprestimo {
  // Atributos públicos que representam os dados do empréstimo
  public id: number;              // Identificador único do empréstimo
  public usuarioId: number;       // ID do usuário que fez o empréstimo
  public livroId: number;         // ID do livro emprestado
  public dataEmprestimo: Date;    // Data em que o empréstimo foi realizado
  public dataDevolucao: Date;     // Data prevista para devolução do livro
  public renovado: boolean;       // Indica se o empréstimo já foi renovado (apenas uma vez permitida)

  // Construtor para inicializar um novo objeto Emprestimo
  constructor(
    id: number,
    usuarioId: number,
    livroId: number,
    dataEmprestimo: Date,
    dataDevolucao: Date,
    renovado: boolean = false     // Por padrão, empréstimo inicia sem renovação
  ) {
    this.id = id;
    this.usuarioId = usuarioId;
    this.livroId = livroId;
    this.dataEmprestimo = dataEmprestimo;
    this.dataDevolucao = dataDevolucao;
    this.renovado = renovado;
  }

  // Método para renovar o empréstimo, adicionando 7 dias à data de devolução
  // Só permite renovação se ainda não tiver sido renovado antes
  renovar() {
    if (this.renovado) {
      // Se já foi renovado, retorna false indicando falha na renovação
      return false;
    }
    // Marca o empréstimo como renovado
    this.renovado = true;
    // Adiciona 7 dias à data de devolução
    this.dataDevolucao.setDate(this.dataDevolucao.getDate() + 7);
    // Retorna true indicando sucesso na renovação
    return true;
  }
}
