export class Livro {
  // Atributos públicos que representam as informações do livro
  public id: number;
  public titulo: string;
  public autor: string;
  public preco: number;
  public quantidade: number;

  // Construtor para criar um novo objeto Livro com os dados iniciais
  constructor(
    id: number,
    titulo: string,
    autor: string,
    preco: number,
    quantidade: number
  ) {
    this.id = id;
    this.titulo = titulo;
    this.autor = autor;
    this.preco = preco;
    this.quantidade = quantidade;
  }

  // Método para alterar a quantidade de livros disponíveis
  // delta pode ser positivo (adicionar) ou negativo (retirar)
  alterarQuantidade(delta: number) {
    this.quantidade += delta;
  }
}
