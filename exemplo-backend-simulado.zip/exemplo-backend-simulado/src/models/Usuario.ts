export class Usuario {
  // Atributos públicos que representam os dados do usuário
  public id: number;
  public nome: string;
  public email: string;
  // A senha é privada para proteger a informação sensível
  private senha: string;

  // Construtor para inicializar um novo objeto Usuario
  constructor(
    id: number,
    nome: string,
    email: string,
    senha: string
  ) {
    this.id = id;
    this.nome = nome;
    this.email = email;
    this.senha = senha;
  }

  // Método para validar se a senha fornecida é igual à senha armazenada
  validarSenha(senha: string): boolean {
    return this.senha === senha;
  }

  // Método para alterar a senha do usuário
  alterarSenha(novaSenha: string) {
    this.senha = novaSenha;
  }
}
