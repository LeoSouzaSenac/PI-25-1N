import { UsuarioService } from './services/UsuarioService';
import { LivroService } from './services/LivroService';
import { EmprestimoService } from './services/EmprestimoService';

function main() {
    const usuarioService = new UsuarioService();
    const livroService = new LivroService();
    const emprestimoService = new EmprestimoService(usuarioService, livroService);
  
    // Criar usuários
    const u1 = usuarioService.criarUsuario('Maria Silva', 'maria@email.com', '123456');
    const u2 = usuarioService.criarUsuario('João Souza', 'joao@email.com', 'abcdef');
  
    // Criar livros
    const l1 = livroService.criarLivro('O Senhor dos Anéis', 'J.R.R. Tolkien', 50, 3);
    const l2 = livroService.criarLivro('Dom Casmurro', 'Machado de Assis', 30, 1);
    const l3 = livroService.criarLivro('Harry Potter', 'J.K. Rowling', 40, 0);
  
    console.log('Usuários cadastrados:', usuarioService.listarUsuarios());
    console.log('Livros cadastrados:', livroService.listarLivros());
  
    // Emprestar livros
    const e1 = emprestimoService.emprestarLivro(u1.id, l1.id);
    if (e1) {
      console.log('Empréstimo 1 criado:', e1);
    } else {
      console.log('Falha ao criar empréstimo 1');
    }
  
    const e2 = emprestimoService.emprestarLivro(u2.id, l2.id);
    if (e2) {
      console.log('Empréstimo 2 criado:', e2);
    } else {
      console.log('Falha ao criar empréstimo 2');
    }
  
    // Tentar emprestar livro indisponível
    const e3 = emprestimoService.emprestarLivro(u1.id, l3.id);
    if (!e3) {
      console.log('Falha ao criar empréstimo para livro indisponível');
    }
  
    // Renovar empréstimo 1
    if (e1) {
      const renovou = emprestimoService.renovarEmprestimo(e1.id);
      console.log('Renovação empréstimo 1:', renovou);
  
      // Tentar renovar novamente (deve falhar)
      const renovou2 = emprestimoService.renovarEmprestimo(e1.id);
      console.log('Renovação empréstimo 1 novamente:', renovou2);
    }
  
    // Devolver empréstimo 2
    if (e2) {
      const devolveu = emprestimoService.devolverLivro(e2.id);
      console.log('Devolução empréstimo 2:', devolveu);
    }
  
    // Listar empréstimos do usuário 1
    const emprestimosU1 = emprestimoService.listarEmprestimosPorUsuario(u1.id);
    console.log(`Empréstimos do usuário ${u1.nome}:`, emprestimosU1);
  
    // Listar todos os empréstimos
    console.log('Todos os empréstimos:', emprestimoService.listarTodos());
  
    // Verificar livros após operações
    console.log('Livros após operações:', livroService.listarLivros());
  }
  
  main();
  
